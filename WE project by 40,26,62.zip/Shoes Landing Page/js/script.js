// Home gallery 
var thumbnails = document.getElementById("thumbnails")
var imgs = thumbnails.getElementsByTagName("img")
var main = document.getElementById("main")
var counter=0;

for(let i=0;i<imgs.length;i++){
  let img=imgs[i]
  
  
  img.addEventListener("click",function(){
  main.src=this.src
})
  
}
// Navbar
let menu = document.querySelector('#menu-btn');
let header = document.querySelector('.header');

menu.onclick = () =>{
  menu.classList.toggle('fa-times');
  header.classList.toggle('active');
  document.body.classList.toggle('active');
};

window.onscroll = () =>{
  if(window.innerWidth < 1200){
    menu.classList.remove('fa-times');
    header.classList.remove('active');
    document.body.classList.remove('active');
  };
};

// Products preview 
let productPreviewContainer = document.querySelector('.products-preview-container');
let prodcutPreview = productPreviewContainer.querySelectorAll('.product-preview');

document.querySelectorAll('.products .slide .btn').forEach(detailBtn =>{
  detailBtn.onclick = () =>{
    productPreviewContainer.style.display = 'block';
    let name = detailBtn.getAttribute('data-product');
    prodcutPreview.forEach(preview =>{
      let target = preview.getAttribute('data-target');
      if(name == target){
       preview.style.display = 'flex';
      };
    });
  };
});

document.querySelectorAll('.products-preview-container .product-preview .fa-times').forEach(close =>{
  close.onclick = () =>{
    productPreviewContainer.style.display = 'none';
    prodcutPreview.forEach(closePreview =>{
      closePreview.style.display = 'none';
    });
  };
});

// Products section js
var swiper = new Swiper(".products-slider", {
  loop:true,
  spaceBetween: 20,
  grabCursor:true,
  centeredSlides: true,
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    991: {
      slidesPerView: 3,
    },
  },
});


// Reviews section js
$(document).ready(function(){
  $("#testimonial-slider").owlCarousel({
      items:3,
      itemsDesktop:[1000,3],
      itemsDesktopSmall:[980,2],
      itemsTablet:[768,2],
      itemsMobile:[650,1],
      pagination:true,
      navigation:false,
      slideSpeed:1000,
      autoPlay:true
  });
});


// Contact section 
const inputs=document.querySelectorAll(".input");

function focusFunc(){
  let parent = this.parentNode;
  parent.classList.add("focus")
}

function blurFunc(){
  let parent = this.parentNode;
  if(this.value == ""){
    parent.classList.remove("focus")
  }

}

inputs.forEach((input) =>{
  input.addEventListener("focus",focusFunc);
  input.addEventListener("blur",blurFunc);
})


// Footer year
const year = document.querySelector('#current-year')
year.innerHTML = new Date().getFullYear()

// Preloader

  var loader = document.getElementById("preloader");
  window.addEventListener("load",function(){
    loader.style.display="none";
  })

